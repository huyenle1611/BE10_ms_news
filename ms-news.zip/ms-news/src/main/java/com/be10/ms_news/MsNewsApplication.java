package com.be10.ms_news;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsNewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsNewsApplication.class, args);
	}

}
